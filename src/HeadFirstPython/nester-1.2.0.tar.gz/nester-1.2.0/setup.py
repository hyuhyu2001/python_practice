from distutils.core import setup

setup(
        name = 'nester',
        version = '1.2.0',
        py_modules = ['nester'],
        author = 'king',
        author_email = 'hfpython@py.com',
        url = 'http://www.baidu.com',
        description = 'A simple printer of nestd lists',
    )
